<?php

namespace App\Http\Controllers;

use App\Helpers\TextTools;
use Illuminate\Http\Request;
use App\Helpers\Tools;

class ToolsController extends Controller
{
    public function index() {

        $titleCase = Tools::text()->titleCase('Mr. Ariful Islam is a trying best web developer in his own world.');
//        $titleCase = (new TextTools())->titleCase('Mr. Ariful Islam is a trying best web developer in his own world.');

        return view('index');
    }
}
