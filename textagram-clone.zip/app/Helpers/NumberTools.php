<?php


namespace App\Helpers;


class NumberTools
{

}
