<?php


namespace App\Helpers;


class TextTools
{
    public function titleCase($text) {
        $smallWordsArray = array('of','a','the','and','an','or','nor','but','is','if','then','else','when', 'at','from','by','on','off','for','in','to','into','with','it', 'as');

        // Split the string into separate words
        $words = explode(' ', $text);

        foreach ($words as $key => $word) {

            // If this word is the first, or it's not one of our small words, capitalise it
            // with ucwords().
            if ($key == 0 or !in_array(strip_tags($word), $smallWordsArray)) {
                $old = strip_tags($word);
                $new = ucfirst($old);
                $words[$key] = str_replace($old,$new,$word);
            }
        }

        // Join the words back into a string
        return implode(' ', $words);
    }
}
