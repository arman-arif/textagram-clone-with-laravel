<?php


namespace App\Helpers;


class EncryptionTools
{

}
