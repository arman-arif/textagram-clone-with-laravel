@extends('layouts.app', ['pageTitle' => "Homepage"])
@section('content')
    @livewire('text-tools')
@endsection
