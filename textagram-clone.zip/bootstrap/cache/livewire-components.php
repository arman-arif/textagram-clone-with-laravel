<?php return array (
  'text-tools' => 'App\\Http\\Livewire\\TextTools',
);