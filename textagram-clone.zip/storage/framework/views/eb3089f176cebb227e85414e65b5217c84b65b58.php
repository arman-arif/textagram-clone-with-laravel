<div>
    <h1>Index Page</h1>
</div>
<?php /**PATH D:\Arman\Web_Projects\laravel_basics\textagram-clone\resources\views/livewire/text-tools.blade.php ENDPATH**/ ?>