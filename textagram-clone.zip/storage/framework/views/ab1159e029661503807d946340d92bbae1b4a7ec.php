
<div class="border-bottom">
  <header class="container d-flex flex-wrap align-items-center justify-content-between justify-content-md-between py-3">
    
    <a href="/" class="d-flex align-items-center col-md-3 mb-2 mb-md-0 text-dark text-decoration-none">
      <h1 class="text-warning h3">Textagram Clone</h1>   
    </a>

    <ul class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
      <li><a href="#" class="nav-link px-2 link-secondary">Home</a></li>
      <li><a href="#" class="nav-link px-2 link-dark">Text Tools</a></li>
      <li><a href="#" class="nav-link px-2 link-dark">Number Tools</a></li>
      <li><a href="#" class="nav-link px-2 link-dark">Encryption Tools</a></li>
      <li><a href="#" class="nav-link px-2 link-dark">About</a></li>
    </ul>

</header>
</div> <?php /**PATH D:\Arman\Web_Projects\laravel_basics\textagram-clone\resources\views/partials/header.blade.php ENDPATH**/ ?>