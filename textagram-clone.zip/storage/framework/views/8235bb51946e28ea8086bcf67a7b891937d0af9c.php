<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('text-tools')->html();
} elseif ($_instance->childHasBeenRendered('YWnCqj2')) {
    $componentId = $_instance->getRenderedChildComponentId('YWnCqj2');
    $componentTag = $_instance->getRenderedChildComponentTagName('YWnCqj2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YWnCqj2');
} else {
    $response = \Livewire\Livewire::mount('text-tools');
    $html = $response->html();
    $_instance->logRenderedChild('YWnCqj2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageTitle' => "Homepage"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Arman\Web_Projects\laravel_basics\textagram-clone\resources\views/index.blade.php ENDPATH**/ ?>